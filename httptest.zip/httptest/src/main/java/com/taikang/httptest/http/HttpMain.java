package com.taikang.httptest.http;

import java.io.IOException;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class HttpMain {

	public static void main(String[] args) throws ClientProtocolException, IOException {
		CloseableHttpClient closeableHttpClient=HttpClients.createDefault(); //1、创建实例
        HttpGet httpGet=new HttpGet("http://www.baidu.com"); //2、创建请求
         
        httpGet.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.122 Safari/537.36 SE 2.X MetaSr 1.0");
         
        CloseableHttpResponse closeableHttpResponse=closeableHttpClient.execute(httpGet); //3、执行
        HttpEntity httpEntity=closeableHttpResponse.getEntity(); //4、获取实体
        System.out.println(EntityUtils.toString(httpEntity, "utf-8")); //5、获取网页内容，并且指定编码
        Header header=httpEntity.getContentType();
        System.out.println(header.toString()); //获取头信息内容
        System.out.println(header.getName().toString()); //这是获取key
        System.out.println(header.getValue().toString()); //这是获取value
         
        //System.out.println(EntityUtils.toString(httpEntity, "utf-8")); //5、获取网页内容，并且指定编码
        closeableHttpResponse.close();
        closeableHttpClient.close();

	}

}
