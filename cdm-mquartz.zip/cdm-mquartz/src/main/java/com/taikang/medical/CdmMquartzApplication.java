package com.taikang.medical;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CdmMquartzApplication {

	public static void main(String[] args) {
		SpringApplication.run(CdmMquartzApplication.class, args);
	}

}
