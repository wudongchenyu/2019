package com.taikang.medical.task;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class MedicalPatientTask {
	
	@Scheduled(cron="0/5 * *  * * ? ")
	public void mytask() {
		log.info("定时任务执行了");
	}

}
