package com;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class HttpClientMain {
	
	public static void main(String[] args) {
		Long aLong = System.nanoTime();
		System.out.println(get("http://www.baidu.com"));
		Long bLong = System.nanoTime();
		System.out.println(bLong-aLong);
	}
	
//	public static void httpclient() {
//		CloseableHttpClient closeableHttpClient=HttpClients.createDefault(); //1、创建实例
//        HttpGet httpGet=new HttpGet("http://www.tuicool.com"); //2、创建请求
//         
//        httpGet.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.122 Safari/537.36 SE 2.X MetaSr 1.0");
//         
//        CloseableHttpResponse closeableHttpResponse=closeableHttpClient.execute(httpGet); //3、执行
//        HttpEntity httpEntity=closeableHttpResponse.getEntity(); //4、获取实体
//         
//        Header header=httpEntity.getContentType();
//        System.out.println(header.toString()); //获取头信息内容
//        System.out.println(header.getName().toString()); //这是获取key
//        System.out.println(header.getValue().toString()); //这是获取value
//         
//        //System.out.println(EntityUtils.toString(httpEntity, "utf-8")); //5、获取网页内容，并且指定编码
//        closeableHttpResponse.close();
//        closeableHttpClient.close();
//	}
	
	
	public static String get(String httpurl) {

        HttpURLConnection connection = null;
        InputStream is = null;
        BufferedReader br = null;
        String result = null;// 返回结果字符串
        try {
            // 创建远程url连接对象
            URL url = new URL(httpurl);
            // 通过远程url连接对象打开一个连接，强转成httpURLConnection类
            connection = (HttpURLConnection) url.openConnection();
            // 设置连接方式：get
            connection.setRequestMethod("GET");
            // 设置连接主机服务器的超时时间：15000毫秒
            connection.setConnectTimeout(15000);
            // 设置读取远程返回的数据时间：60000毫秒
            connection.setReadTimeout(60000);
            // 发送请求
            connection.connect();
            // 通过connection连接，获取输入流
            if (connection.getResponseCode() == 200) {
                is = connection.getInputStream();
                // 封装输入流is，并指定字符集
                br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                // 存放数据
                StringBuffer sbf = new StringBuffer();
                String temp = null;
                while ((temp = br.readLine()) != null) {
                    sbf.append(temp);
                    sbf.append("\r\n");
                }
                result = sbf.toString();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // 关闭资源
            if (null != br) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (null != is) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            connection.disconnect();// 关闭远程连接
        }

        return result;
	}

}
