/**
 * 
 */
/**
 * @author wudon
 *
 */
module http2 {
	requires java.net.http;
	
}