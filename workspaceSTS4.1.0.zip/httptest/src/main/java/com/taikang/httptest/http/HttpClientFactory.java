package com.taikang.httptest.http;

public class HttpClientFactory {
	
	private static HttpAsyncClientConnection httpAsyncClient = new HttpAsyncClientConnection();
	 
	private HttpClientFactory() {
		
	}
 
	private static HttpClientFactory httpClientFactory = new HttpClientFactory();
 
	public static HttpClientFactory getInstance() {
		return httpClientFactory;
	}
 
	public HttpAsyncClientConnection getHttpAsyncClientPool() {
		return httpAsyncClient;
	}

}
