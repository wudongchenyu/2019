package com.taikang.httptest.http;

import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

public class HttpMain {

	public static void main(String[] args) throws ClientProtocolException, IOException {
		
		CloseableHttpAsyncClient asyncHttpClient = HttpClientFactory.getInstance().getHttpAsyncClientPool().getAsyncHttpClient();
		httpAsyncClientsPool(asyncHttpClient,"http://114.55.3.97:8081");

	}
	
	public void test() throws IOException {
		System.out.println();
		Long beginLong = System.nanoTime();
		testHttpAsyncClients();
		System.out.println(System.nanoTime() - beginLong);
		testHttpAsyncClients();
		System.out.println(System.nanoTime() - beginLong);
		testHttpAsyncClients();
		System.out.println(System.nanoTime() - beginLong);
		testHttpAsyncClients();
		System.out.println(System.nanoTime() - beginLong);
		testHttpAsyncClients();
		System.out.println(System.nanoTime() - beginLong);
		CloseableHttpAsyncClient asyncHttpClient = HttpClientFactory.getInstance().getHttpAsyncClientPool().getAsyncHttpClient();
		httpAsyncClientsPool(asyncHttpClient);
		System.out.println(System.nanoTime() - beginLong);
		httpAsyncClientsPool(asyncHttpClient);
		System.out.println(System.nanoTime() - beginLong);
		httpAsyncClientsPool(asyncHttpClient);
		System.out.println(System.nanoTime() - beginLong);
		httpAsyncClientsPool(asyncHttpClient);
		System.out.println(System.nanoTime() - beginLong);
		httpAsyncClientsPool(asyncHttpClient);
		System.out.println(System.nanoTime() - beginLong);
		asyncHttpClient.close();
	}
	
	public static void testHttpSyncClients() {
		CloseableHttpClient closeableHttpClient = HttpClients.createDefault(); //1、创建实例
		HttpGet httpGet=new HttpGet("http://www.baidu.com"); //2、创建请求
       
		httpGet.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.122 Safari/537.36 SE 2.X MetaSr 1.0");
       
		CloseableHttpResponse closeableHttpResponse;
		try {
			closeableHttpResponse = closeableHttpClient.execute(httpGet);
			HttpEntity httpEntity=closeableHttpResponse.getEntity(); //4、获取实体
	      	System.out.println(EntityUtils.toString(httpEntity, "utf-8")); //5、获取网页内容，并且指定编码
	      	Header header=httpEntity.getContentType();
	      	System.out.println(header.toString()); //获取头信息内容
	      	System.out.println(header.getName().toString()); //这是获取key
	      	System.out.println(header.getValue().toString()); //这是获取value
	       
	      	System.out.println(EntityUtils.toString(httpEntity, "utf-8")); //5、获取网页内容，并且指定编码
	      	closeableHttpResponse.close();
	      	closeableHttpClient.close();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void testHttpAsyncClients() {
		CloseableHttpAsyncClient httpclient = HttpAsyncClients.createDefault();
        try {
            httpclient.start();
            HttpGet request = new HttpGet("http://www.baidu.com");
            Future<HttpResponse> future = httpclient.execute(request, null);
            HttpResponse response = future.get();
            System.out.println("Response: " + response.getStatusLine());
            System.out.println(EntityUtils.toString(response.getEntity(), "utf-8"));
            System.out.println("Shutting down");
        } catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
            try {
				httpclient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
        }
        System.out.println("Done");
	}
	
	public static void httpAsyncClientsPool(CloseableHttpAsyncClient asyncHttpClient) {
		try {
			asyncHttpClient.start();
            HttpGet request = new HttpGet("http://www.baidu.com");
            Future<HttpResponse> future = asyncHttpClient.execute(request, null);
            HttpResponse response = future.get();
            System.out.println("Response: " + response.getStatusLine());
            System.out.println(EntityUtils.toString(response.getEntity(), "utf-8"));
            System.out.println("Shutting down");
        } catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void httpAsyncClientsPool(CloseableHttpAsyncClient asyncHttpClient, String url) throws IOException {
		try {
			asyncHttpClient.start();
			HttpPost request = new HttpPost(url);
			NameValuePair pair = new BasicNameValuePair("a", "aasd");
			HttpEntity entity = new UrlEncodedFormEntity(Arrays.asList(pair));
			request.setEntity(entity);
            Future<HttpResponse> future = asyncHttpClient.execute(request, null);
            HttpResponse response = future.get();
            System.out.println("Response: " + response.getStatusLine());
            System.out.println(EntityUtils.toString(response.getEntity(), "utf-8"));
            System.out.println("Shutting down");
        } catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

}
