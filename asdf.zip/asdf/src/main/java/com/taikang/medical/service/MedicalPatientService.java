package com.taikang.medical.service;

import org.springframework.stereotype.Service;

@Service
public class MedicalPatientService {

}
