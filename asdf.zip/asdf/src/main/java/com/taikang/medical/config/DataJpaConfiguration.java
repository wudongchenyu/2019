package com.taikang.medical.config;

import java.util.Properties;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import lombok.extern.log4j.Log4j2;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
	entityManagerFactoryRef = "entityManagerFactory",
			transactionManagerRef = "transactionManager",
			basePackages = {"com.taikang.medical.jpa"}
)
@AutoConfigureAfter(DataSourceConfig.class)
@Log4j2
public class DataJpaConfiguration {
	
	@Value(value = "${hibernate.hbm2ddl.auto}")
	private String hbm2ddl;
	
	@Value(value = "${hibernate.dialect}")
	private String dialect;
	
	@Value(value = "${hibernate.show-sql}")
	private Boolean showSql;
	
	private Properties jpaProperties;
	
	private @Autowired @Qualifier("dataSource") DataSource dataSource;

	public @Bean @Primary LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
	    vendorAdapter.setGenerateDdl(false);
	    vendorAdapter.setShowSql(showSql);
	    log.info(showSql);
	    LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
	    factory.setJpaProperties(getPrpperties());
	    factory.setJpaVendorAdapter(vendorAdapter);
	    factory.setPackagesToScan("com.taikang.medical.po");
	    factory.setDataSource(dataSource);
		return factory;
	}
	
	public @Bean EntityManager entityManager(EntityManagerFactoryBuilder builder) {
		return entityManagerFactory().getObject().createEntityManager();
	}
	
	public @Bean @Primary PlatformTransactionManager transactionManager() {
		return new JpaTransactionManager(entityManagerFactory().getObject());
	}

	private Properties getPrpperties() {
		jpaProperties = new Properties();
		jpaProperties.setProperty("hibernate.dialect", dialect);
		jpaProperties.setProperty("hibernate.hbm2ddl.auto", hbm2ddl);
		jpaProperties.setProperty("hibernate.use_sql_comments", "true");
		return jpaProperties;
	}
	
}
