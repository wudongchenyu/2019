package com.taikang.medical.po;

public class MedicalPatient {

}
