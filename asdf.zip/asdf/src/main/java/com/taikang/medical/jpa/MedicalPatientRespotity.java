package com.taikang.medical.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.taikang.medical.po.MedicalPatient;

public interface MedicalPatientRespotity extends JpaRepository<MedicalPatient, String>{

}
