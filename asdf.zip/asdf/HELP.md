# Getting Started

### Guides
The following guides illustrate how to use some features concretely:

* [Accessing data with MySQL](https://spring.io/guides/gs/accessing-data-mysql/)
* [Quick Start](https://github.com/mybatis/spring-boot-starter/wiki/Quick-Start)

