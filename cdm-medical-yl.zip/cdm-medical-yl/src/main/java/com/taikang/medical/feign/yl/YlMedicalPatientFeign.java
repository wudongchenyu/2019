package com.taikang.medical.feign.yl;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name="ylMedicalPatientFeign",url = "")
public interface YlMedicalPatientFeign {
	
	@PostMapping(path = "",produces="")
	public void name(@RequestParam(value = "name") String name);

}
